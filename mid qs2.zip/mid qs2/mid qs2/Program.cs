﻿using System;
using System.Text;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string registrationNumber = "FA21-BCS-002";
        string firstName = "Nida";
        string lastName = "Eman";
        string favoriteMovie = "Wednesday";

        // Extract components based on the specifications
        string digits = ExtractDigits(registrationNumber);
        string secondLetterFirstName = firstName[1].ToString(); 
        string secondLetterLastName = lastName[1].ToString();   
        string movieCharacters = favoriteMovie.Substring(2, 2); 
        string specialCharacters = "!@$%^&*()_+-=<>?"; 

       
        string password = GeneratePassword(digits, secondLetterFirstName, secondLetterLastName, movieCharacters, specialCharacters);

        Console.WriteLine("Generated Password: " + password);
    }

    static string ExtractDigits(string regNo)
    {
        // regex to find the digits in the registration number
        MatchCollection matches = Regex.Matches(regNo, @"\d");
        StringBuilder digits = new StringBuilder();

        foreach (Match match in matches)
        {
            digits.Append(match.Value);
        }

        // Return the first 2 digits
        return digits.ToString().Substring(0, 2);
    }

    static string GeneratePassword(string digits, string secondLetterFirstName, string secondLetterLastName, string movieCharacters, string specialCharacters)
    {
        Random random = new Random();
        StringBuilder passwordBuilder = new StringBuilder();

        // Add required components
        passwordBuilder.Append(digits);                            
        passwordBuilder.Append(secondLetterFirstName);            
        passwordBuilder.Append(secondLetterLastName);            
        passwordBuilder.Append(movieCharacters);                   

        while (passwordBuilder.Length < 14)
        {
            int index = random.Next(specialCharacters.Length);
            passwordBuilder.Append(specialCharacters[index]);
        }
        //shuffle arrays
        char[] passwordArray = passwordBuilder.ToString().ToCharArray();
        Shuffle(passwordArray);

        return new string(passwordArray, 0, 14);
    }

    static void Shuffle(char[] array)
    {
        Random random = new Random();
        int n = array.Length;
        for (int i = n - 1; i > 0; i--)
        {
            int j = random.Next(i + 1);
            // Swap
            char temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }
}
